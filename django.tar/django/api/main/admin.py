from django.contrib import admin # from .models import Post, NewTable, Product 
# from .models import Request_form # Request form add
from .models import Post


# Register your models here.--------------------------------------------------------

admin.site.register(Post)
# admin.site.register(NewTable)
# admin.site.register(Test)


# admin.site.register(Test) # Request form bulid

# class Request_formAdmin(admin.ModelAdmin):
#       list_display = ['Model','Subject', 'Request_department', 'Author', 'Status', 'due_date']
#       list_per_page = 5
#       search_fields = ['Model', 'Request_department', 'Author', 'Status']
#       list_filter = ['Model', 'Request_department', 'Author', 'Status', 'pub_date']

class Post_formAdmin(admin.ModelAdmin):
      list_display = ['title','slug', 'body', 'pub_date']
      list_per_page = 5
      search_fields = ['title','slug']
      list_filter = ['title','slug', 'body', 'pub_date']

