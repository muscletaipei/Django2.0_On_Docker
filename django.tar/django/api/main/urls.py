from django.urls import path
# from . import views
from django.urls import include
from django.conf.urls import url #新增這一列
from main.views import about
from main.views import index_view


app_name = 'main'
urlpatterns = [
    # path('', views.main),
     path('' , index_view, name="index"), 
]

    


