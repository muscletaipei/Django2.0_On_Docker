from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime
# from main.models import Request_form


# Create your views here.--------------------------------------------------


def index_view(request):
    # posts = Post.objects.all()
    # now = datetime.now()
    return render(request, 'index.html' , locals())

def info_view(request):
    return render(request, 'info.html')

def booking_view(request):
    return render(request, 'booking.html')

# def request_list_view(request): # get all the posts
#     post_list = Request_form.objects.all()
#     return render(request,'request_list.html',{'post_list': post_list})

